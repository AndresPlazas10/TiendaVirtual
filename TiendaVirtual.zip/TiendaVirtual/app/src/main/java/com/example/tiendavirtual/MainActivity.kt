package com.example.tiendavirtual

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TiendaVirtualTheme {
                MainApp()
            }
        }
    }
}

@Composable
fun MainApp(viewModel: TiendaViewModel = viewModel()) {
    var currentScreen by remember { mutableStateOf("home") }

    when (currentScreen) {
        "home" -> HomeScreen(
            onConsultarClick = { currentScreen = "consultar" },
            onRegistrarVentaClick = { currentScreen = "registrar_venta" },
            onRegistrarArticuloClick = { currentScreen = "registrar_articulo" }
        )
        "consultar" -> ConsultarArticulosScreen(
            viewModel = viewModel,
            onBack = { currentScreen = "home" }
        )
        "registrar_articulo" -> RegistrarArticuloScreen(
            viewModel = viewModel,
            onBack = { currentScreen = "home" }
        )
        "registrar_venta" -> RegistrarVentaScreen(
            viewModel = viewModel,
            onBack = { currentScreen = "home" }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    onConsultarClick: () -> Unit,
    onRegistrarVentaClick: () -> Unit,
    onRegistrarArticuloClick: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("TIENDA VIRTUAL", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = MaterialTheme.colorScheme.primary,
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Button(
                onClick = onConsultarClick,
                modifier = Modifier.fillMaxWidth().height(56.dp)
            ) {
                Text("CONSULTAR ARTICULOS")
            }
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = onRegistrarVentaClick,
                modifier = Modifier.fillMaxWidth().height(56.dp)
            ) {
                Text("REGISTRAR VENTA")
            }
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = onRegistrarArticuloClick,
                modifier = Modifier.fillMaxWidth().height(56.dp)
            ) {
                Text("REGISTRAR ARTICULO")
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConsultarArticulosScreen(viewModel: TiendaViewModel, onBack: () -> Unit) {
    val articulos by viewModel.allArticulos.collectAsState(initial = emptyList())

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("ARTICULOS", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    Button(onClick = onBack, modifier = Modifier.padding(start = 8.dp)) {
                        Text("VOLVER")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(innerPadding).padding(16.dp)
        ) {
            if (articulos.isEmpty()) {
                Text(text = "No hay artículos.", modifier = Modifier.align(Alignment.CenterHorizontally))
            } else {
                LazyColumn {
                    items(articulos) { articulo ->
                        ArticuloItem(articulo)
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RegistrarArticuloScreen(viewModel: TiendaViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var id by remember { mutableStateOf("") }
    var nombre by remember { mutableStateOf("") }
    var descripcion by remember { mutableStateOf("") }
    var precio by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("NUEVO ARTICULO", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    Button(onClick = onBack, modifier = Modifier.padding(start = 8.dp)) {
                        Text("VOLVER")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(innerPadding).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            OutlinedTextField(value = id, onValueChange = { id = it }, label = { Text("ID") }, modifier = Modifier.fillMaxWidth())
            Spacer(modifier = Modifier.height(12.dp))
            OutlinedTextField(value = nombre, onValueChange = { nombre = it }, label = { Text("NOMBRE") }, modifier = Modifier.fillMaxWidth())
            Spacer(modifier = Modifier.height(12.dp))
            OutlinedTextField(value = descripcion, onValueChange = { descripcion = it }, label = { Text("DESCRIPCIÓN") }, modifier = Modifier.fillMaxWidth())
            Spacer(modifier = Modifier.height(12.dp))
            OutlinedTextField(value = precio, onValueChange = { precio = it }, label = { Text("PRECIO") }, modifier = Modifier.fillMaxWidth())
            Spacer(modifier = Modifier.height(32.dp))
            Button(
                modifier = Modifier.fillMaxWidth().height(56.dp),
                onClick = {
                    val idInt = id.toIntOrNull()
                    val precioInt = precio.toIntOrNull()
                    if (idInt != null && precioInt != null && nombre.isNotBlank()) {
                        scope.launch {
                            if (viewModel.existeArticulo(idInt)) {
                                Toast.makeText(context, "ID ya existe", Toast.LENGTH_SHORT).show()
                            } else {
                                viewModel.insertArticulo(Articulo(idInt, nombre, descripcion, precioInt))
                                Toast.makeText(context, "Guardado", Toast.LENGTH_SHORT).show()
                                onBack()
                            }
                        }
                    } else {
                        Toast.makeText(context, "Datos inválidos", Toast.LENGTH_SHORT).show()
                    }
                }
            ) {
                Text("AGREGAR")
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RegistrarVentaScreen(viewModel: TiendaViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var grupo by remember { mutableStateOf("") }
    var idArticulo by remember { mutableStateOf("") }
    var cantidad by remember { mutableStateOf("") }
    var valor by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("REGISTRAR VENTA", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    Button(onClick = onBack, modifier = Modifier.padding(start = 8.dp)) {
                        Text("VOLVER")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(innerPadding).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            OutlinedTextField(value = grupo, onValueChange = { grupo = it }, label = { Text("GRUPO") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = idArticulo, onValueChange = { idArticulo = it }, label = { Text("ID ARTICULO") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = cantidad, onValueChange = { cantidad = it }, label = { Text("CANTIDAD") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = valor, onValueChange = { valor = it }, label = { Text("VALOR TOTAL") }, modifier = Modifier.fillMaxWidth())
            Spacer(modifier = Modifier.height(32.dp))
            Button(
                modifier = Modifier.fillMaxWidth().height(56.dp),
                onClick = {
                    val gInt = grupo.toIntOrNull()
                    val idArt = idArticulo.toIntOrNull()
                    val cant = cantidad.toIntOrNull()
                    val valTot = valor.toIntOrNull()
                    if (gInt != null && idArt != null && cant != null && valTot != null) {
                        scope.launch {
                            if (viewModel.existeArticulo(idArt)) {
                                viewModel.insertVenta(Venta(grupo = gInt, id_articulo = idArt, cantidad = cant, valor = valTot))
                                Toast.makeText(context, "Venta registrada", Toast.LENGTH_SHORT).show()
                                onBack()
                            } else {
                                Toast.makeText(context, "El artículo no existe", Toast.LENGTH_SHORT).show()
                            }
                        }
                    } else {
                        Toast.makeText(context, "Datos inválidos", Toast.LENGTH_SHORT).show()
                    }
                }
            ) {
                Text("REGISTRAR VENTA")
            }
        }
    }
}

@Composable
fun ArticuloItem(articulo: Articulo) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(text = articulo.nombre.uppercase(), fontWeight = FontWeight.Bold)
                Text(text = "ID: ${articulo.id}", style = MaterialTheme.typography.labelSmall)
            }
            Text(text = articulo.descripcion, style = MaterialTheme.typography.bodySmall)
            Text(text = "$ ${articulo.precio_unitario}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black)
        }
    }
}
