package com.example.tiendavirtual

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch

// --- ENTIDADES (Tablas) ---

@Entity(tableName = "articulos")
data class Articulo(
    @PrimaryKey val id: Int,
    val nombre: String,
    val descripcion: String,
    val precio_unitario: Int
)

@Entity(
    tableName = "ventas",
    foreignKeys = [
        ForeignKey(
            entity = Articulo::class,
            parentColumns = ["id"],
            childColumns = ["id_articulo"],
            onDelete = ForeignKey.NO_ACTION
        )
    ],
    indices = [Index(value = ["id_articulo"])]
)
data class Venta(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val grupo: Int,
    val id_articulo: Int,
    val cantidad: Int,
    val valor: Int
)

// --- DAO (Consultas) ---

@Dao
interface TiendaDao {
    @Insert
    suspend fun insertArticulo(articulo: Articulo)

    @Query("SELECT * FROM articulos WHERE id = :id LIMIT 1")
    suspend fun getArticuloById(id: Int): Articulo?

    @Query("SELECT * FROM articulos")
    fun getAllArticulos(): Flow<List<Articulo>>

    @Insert
    suspend fun insertVenta(venta: Venta)
}

// --- BASE DE DATOS ---

@Database(entities = [Articulo::class, Venta::class], version = 1, exportSchema = false)
abstract class TiendaDatabase : RoomDatabase() {
    abstract fun tiendaDao(): TiendaDao

    companion object {
        @Volatile
        private var Instance: TiendaDatabase? = null

        fun getDatabase(context: Context): TiendaDatabase {
            return Instance ?: synchronized(this) {
                Room.databaseBuilder(context, TiendaDatabase::class.java, "tienda_database")
                    .addCallback(object : Callback() {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            super.onCreate(db)
                            Instance?.let { database ->
                                CoroutineScope(Dispatchers.IO).launch {
                                    val dao = database.tiendaDao()
                                    dao.insertArticulo(Articulo(1, "Pantalon", "Pantalon de koaj", 80))
                                    dao.insertArticulo(Articulo(2, "Camisa", "camisa de koaj", 60))
                                    dao.insertArticulo(Articulo(3, "gorra", "gorra de koah", 70))
                                    dao.insertArticulo(Articulo(4, "Tennis", "Tennis de koaj", 120))
                                    dao.insertArticulo(Articulo(5, "Medias", "medias de koaj", 20))
                                }
                            }
                        }
                    })
                    .build()
                    .also { Instance = it }
            }
        }
    }
}

// --- VIEWMODEL (Lógica) ---

class TiendaViewModel(application: Application) : AndroidViewModel(application) {
    private val dao = TiendaDatabase.getDatabase(application).tiendaDao()
    
    val allArticulos: Flow<List<Articulo>> = dao.getAllArticulos()

    suspend fun existeArticulo(id: Int): Boolean {
        return dao.getArticuloById(id) != null
    }

    fun insertArticulo(articulo: Articulo) = viewModelScope.launch {
        dao.insertArticulo(articulo)
    }

    fun insertVenta(venta: Venta) = viewModelScope.launch {
        dao.insertVenta(venta)
    }
}
