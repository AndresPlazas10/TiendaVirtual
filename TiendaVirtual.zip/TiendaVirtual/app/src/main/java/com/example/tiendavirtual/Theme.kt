package com.example.tiendavirtual

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// Colores
val Black = Color(0xFF000000)
val White = Color(0xFFFFFFFF)
val Gray900 = Color(0xFF121212)
val Gray100 = Color(0xFFF5F5F5)
val Gray400 = Color(0xFFBDBDBD)
val Gray600 = Color(0xFF757575)

private val LightColors = lightColorScheme(
    primary = Black,
    onPrimary = White,
    background = White,
    surface = White,
    outline = Gray400
)

private val DarkColors = darkColorScheme(
    primary = White,
    onPrimary = Black,
    background = Black,
    surface = Gray900,
    outline = Gray600
)

@Composable
fun TiendaVirtualTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColors else LightColors

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography(
            bodyLarge = TextStyle(
                fontFamily = FontFamily.Default,
                fontWeight = FontWeight.Normal,
                fontSize = 16.sp
            )
        ),
        content = content
    )
}
